package ch13.web.userinfo;

//dao 패키지에서 구현한 내용을 실현하는 페이지!! 

/* 1. DB의 유형에 따라 그에 알맞는 DAO가 인스턴스 되도록 해야 한다. 
 * 2. file의 정보를 기준으로 알맞는 DAO가 호출 되도록 조건문을 코딩한다.
 * 3. file은 Properties 클래스를 import 하여 수행한다. ( 자세한건 다음 강의에서)
 * */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import ch13.domain.userinfo.UserInfo;
import ch13.domain.userinfo.dao.UserInfoDao;
import ch13.domain.userinfo.dao.mysql.UserInfoMySqlDao;
import ch13.domain.userinfo.dao.oracle.UserInfoOracleDao;

public class UserInfoClient {

	public static void main(String[] args) throws IOException {
		FileInputStream fis = new FileInputStream("db.properties"); 
		// db.properties라는 이름의 파일에 적힌 내용을 가지고 오기 위해 작성한다.
		
		Properties prop = new Properties();  
		prop.load(fis); 
		//데이터를 하나의 쌍 (묶음으로, key:value로) 읽어 올 수 있게해주는 라이브러리
		
		String dbType = prop.getProperty("DBTYPE"); //key값을 입력해주면 된다 그럼 알아서 value 값이 불러지게 된다. 
		
		UserInfo userInfo = new UserInfo();
		UserInfoDao userInfoDao = null;
		userInfo.setUserId("alsdnrdld");
		//userInfo.setUserName("김민욱");
		//userInfo.setPassword("sldlalQnd1@");
		
		if(dbType.equals("ORACLE")) {
			userInfoDao = new UserInfoOracleDao();
		}else if(dbType.equals("MYSQL")) {
			userInfoDao = new UserInfoMySqlDao();
		}else {
			System.out.println("db error");
			return;
		}
		
		userInfoDao.insertUserInfo(userInfo);
		userInfoDao.updateUserInfo(userInfo);
		userInfoDao.deleteUserInfo(userInfo);
		
	}

}
