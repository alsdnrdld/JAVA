package ch13.domain.userinfo;
 // DAO에 입력될 값을 받아줄 Class 
public class UserInfo {
	private String userId;
	private String password;
	private String userName;    // private로 하지 않으면 UserInfo.변수명  으로 접근 할 수 있게 되어버린다.
	 
	public String getUserId() {
		return userId;
	}
	public String getPassword() {
		return password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
}
