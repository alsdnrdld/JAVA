package ch13.domain.userinfo.dao;
// dao 패키지에서 제공되어야 할 메서드를 선언한 인터페이스

import ch13.domain.userinfo.UserInfo;

public interface UserInfoDao {
	void insertUserInfo(UserInfo userInfo);
	void updateUserInfo(UserInfo userInfo);
	void deleteUserInfo(UserInfo userInfo);
	
	/* Oracle , Mysql DAO 에서 각각에 알맞는 메서드로
	 * 재 정의해서 쓸 것이다. 
	 * 인터페이스는 어떤 기능을 할 것인지 선언만!!! 
	 * 각 상황, 의도에 맞게 implements한 클래스에서 Override!!
	 * 그게 인터페이스의 기본 매커니즘
	 * */
	
	/* 다형성을 구현 할 수 있게 된다. 
	 * 
	 * */
	
}
