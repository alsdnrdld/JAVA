from flask import Flask, render_template, jsonify, request
app = Flask(__name__)

from pymongo import MongoClient
client = MongoClient('localhost', 27017)
db = client.dbsparta

## HTML을 주는 부분
@app.route('/')
def home():
    return render_template('homework_1.html')

## API 역할을 하는 부분
@app.route('/order', methods=['POST'])
def insert_order():
    name_receive = request.form['name_input']
    num_receive = request.form['num_input']
    address_receive = request.form['address_input']
    phone_receive = request.form['phone_input']
    # 이제 input타입의 클래스의  값을 _input 이름의 변수에 .val() 해주는 것을 homework_1.html에 코딩!
    doc={'name':name_receive,'num':num_receive,'address': address_receive,'phone':phone_receive}
    db.orders.insert_one(doc)
    return jsonify({'msg': '주문 내역 저장 완료~'})


@app.route('/order', methods=['GET'])
def show_orders():
    orders = list(db.orders.find({},{'_id':False})) # bookreview에 id 칼럼이 없으므로 ,{_id':False} 칼럼을 써주지 않으면 오류가 떠서 아에 안가지고 온다!!!
    return jsonify({'result': 'success','all_orders': orders})



if __name__ == '__main__':
   app.run('0.0.0.0',port=5000,debug=True)