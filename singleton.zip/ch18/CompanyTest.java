package ch18;

import java.util.Calendar;

public class CompanyTest {

	public static void main(String[] args) {
		Company company1 = Company.getInstance();
		Company company2 = Company.getInstance();
		
		System.out.println(company1);
		System.out.println(company2);
		// 같은 주소값 즉 같은 인스턴스를 공유 하고 있음을 알 수 있다. 
		
		// 달력과 같이 반드시 1개로 통일되어 공용하는 정보가 있어야 할 때 싱글톤을 쓴다.
		Calendar calendar = Calendar.getInstance();
		
		

	}

}
