package ch18;

public class Company {
	/* 싱글톤은 오직 1개의 인스턴스만을 가능하게 하는 디자인 패턴이다
	 * private을 붙임으로써 아무나 접근하여 생성자를 가지고 인스턴스 하는 것을 
	 * 못하게 막아둔다
	 */
	private Company() {
		 
	}
	
	/* 유일한 인스턴스를 만들어 준다.
	 * 그리고 이 유일한 인스턴스를 외부에서 쓸 수 있도록 해준다. 
	 * */
	private static Company instance = new Company();  // 얘는 아직 heap영역에 존재하지 않는다.

	
	/* 여기서 static을 써줘야 한다!! 반드시 
	 * 여기서 static을 쓰지 않으면 타 클래스에서 new Company(); 를 통해
	 * 인스턴스를 해야만 gwtInstance를 쓸 수 있게 되어버린다.
	 * 그런데 우리는 맨 위에서 private으로 제한해 놨기 때문에 인스턴스가 안된다.
	 * static으로 해줘야 타 클래스에서 인스턴스 없이 Company.getInstance를 통해 
	 * 우리가 유일하게 작성해둔 instance를 인스턴스 할 수 있게 된다.   
	 * */
	
	public static Company getInstance() { 
		if (instance == null) {
			instance = new Company();
		}
		return instance;
	}
	
  
		
}

